from flask import Flask, render_template, redirect, send_from_directory, request, abort
import os

app = Flask(__name__)

sat = None
DATA_PATH = None


@app.route('/')
def index():
    mode = ["AUTO", "MANUAL", "DELAY"][sat.mode]
    return render_template("index.html", mode=mode, sat=sat)


@app.route("/api/capture/start")
def start_capture():
    sat.start_capture()
    return redirect("/")


@app.route("/api/capture/stop")
def stop_capture():
    sat.stop_capture()
    return redirect("/")


@app.route("/api/download")
def download():
    nb = request.args.get("data_nb")
    if nb is None or not os.path.exists(DATA_PATH+"/data{}.tar.gz".format(nb)):
        return abort(404)
    return send_from_directory(DATA_PATH, "data{}.tar.gz".format(nb))


@app.route("/api/buzzer/start")
def start_buzz():
    sat.start_buzzer()
    return redirect("/")


@app.route("/api/buzzer/stop")
def stop_buzz():
    sat.stop_buzzer()
    return redirect("/")


@app.route("/api/cansat/shutdown")
def shutdown():
    sat.shutdown()
    return redirect("/shutdown")


@app.route("/shutdown")
def shutdown_status():
    shut = sat.shutdown_flag
    run = sat.running
    sav = sat.saving
    if shut or run or sav:
        status = "Arrêt en cours"
    else:
        status = "Arrêté"
    return render_template("shutdown.html", status=status)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
